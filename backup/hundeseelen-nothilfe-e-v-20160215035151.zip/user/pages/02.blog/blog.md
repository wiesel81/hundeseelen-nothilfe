---
title: 'Home alt'
published: false
body_classes: 'header-image fullwidth'
menu: 'Wir suchen ein Zuhause'
content:
    items: '@self.children'
    limit: 5
    pagination: true
    url_taxonomy_filters: true
    order:
        dir: desc
        by: date
sitemap:
    changefreq: monthly
blog_url: blog
feed:
    description: 'Sample Blog Description'
    limit: 10
pagination: true
---

# Hundeseelen-Nothilfe e.V.
## Sei du die Veränderung, die du dir für die Welt wünschst!
