---
title: 'Kontakt & Notfälle'
image_align: left
---

####Kontakt

E-Mail senden an:

[hundeseelen-nothilfe@hotmail.com](mailto:hundeseelen-nothilfe@hotmail.com)

Bei dringenden Fragen oder in Notfällen ist auch die telefonische Konkakt-Aufnahme möglich:

_+43(0) 699 110 55 495_